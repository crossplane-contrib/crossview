# Crossview Helm Chart

This Helm chart deploys Crossview, a Crossplane resource visualization and management platform, on a Kubernetes cluster.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- A Kubernetes cluster with appropriate RBAC permissions
- (Optional) Ingress controller if you want to use Ingress

## Recent Updates

- Updated PostgreSQL image to latest version (PostgreSQL 18 compatible)
- Fixed PostgreSQL volume mount path for PostgreSQL 18 compatibility
- Improved chart version synchronization in CI/CD pipeline
- Enhanced OCI registry integration
- Modernized secret handling: plain strings = chart creates secret; secretKeyRef = references existing secret
- Removed deprecated existingSecret / existingSecretKeys fields

## Installation

### For end users: Install from OCI Registry (recommended for production)

The chart is published to GHCR on every push/tag. Install directly:

```bash
# Latest version from GHCR
helm install crossview oci://ghcr.io/crossplane-contrib/crossview-chart/crossview \
  --namespace crossview \
  --create-namespace \
  --set secrets.dbPassword=$(openssl rand -base64 16) \
  --set secrets.sessionSecret=$(openssl rand -base64 32) \
  --set secrets.OIDCClientSecret=$(openssl rand -base64 32)
```

Or specify a version:

```bash
helm install crossview oci://ghcr.io/crossplane-contrib/crossview-chart/crossview \
  --version 3.5.3 \
  --namespace crossview \
  --create-namespace \
  --set secrets.dbPassword=your-db-password \
  --set secrets.sessionSecret=your-session-secret
```

### For developers / contributors: Install from local chart

Clone the repo and install from source (useful for testing changes):

```bash
git clone https://github.com/crossplane-contrib/crossview.git
cd crossview/helm/crossview

helm install crossview . \
  -f /path/to/your-custom-values.yaml \
  --namespace crossview \
  --create-namespace
```

Upgrade after local changes:

```bash
helm upgrade crossview . \
  -f /path/to/your-custom-values.yaml \
  --namespace crossview
```

### Quick start with minimal secrets (chart creates them)

```yaml
helm install crossview ./helm/crossview \
  --namespace crossview \
  --create-namespace \
  --set secrets.adminUsername=admin \
  --set secrets.adminPassword=ChangeThisImmediately2026! \
  --set secrets.dbPassword=$(openssl rand -base64 16) \
  --set secrets.sessionSecret=$(openssl rand -base64 32) \
  --set secrets.OIDCClientSecret=$(openssl rand -base64 32)
```

## Configuration

The following table lists the configurable parameters and their default values:

| Parameter                        | Description                                                                 | Default / Example                          |
|----------------------------------|-----------------------------------------------------------------------------|--------------------------------------------|
| `image.repository`               | Docker image repository                                                     | `ghcr.io/crossplane-contrib/crossview`               |
| `image.tag`                      | Image tag (leave empty for Chart.AppVersion)                                | `""` (uses chart version)                  |
| `app.replicas`                   | Number of replicas                                                          | `1`                                        |
| `database.enabled`               | Enable bundled PostgreSQL                                                   | `true`                                     |
| `config.database.enabled`        | Enable application database access; independent of bundled PostgreSQL       | `true`                                     |
| `config.sso.oidc.providerName`    | Optional OIDC login-button name; defaults to OIDC when empty                 | `""`                                       |
| `config.sso.oidc.providerIcon`    | Optional browser-accessible icon URL; issuer favicon when empty             | `""`                                       |
| `config.sso.saml.providerName`    | Optional SAML login-button name; defaults to SAML when empty                 | `""`                                       |
| `config.sso.saml.providerIcon`    | Optional browser-accessible SAML icon URL; uses the default icon when empty  | `""`                                       |
| `config.ref`                     | Reference existing ConfigMap (skips chart-generated config)                 | `""`                                       |
| `config.server.contextAliases`   | Map of kube context names to short UI labels                                | `{}`                                        |
| `config.server.managed.cacheTTLSeconds` | Managed resources cache TTL per context (seconds)                 | `300`                                       |
| `config.server.managed.pageSize` | Page size for per-type Kubernetes LIST calls                           | `1000`                                      |
| `config.server.managed.maxItemsPerType` | Max items fetched per managed resource type                   | `5000`                                      |
| `config.server.managed.maxConcurrency` | Max parallel per-type LIST calls                              | `10`                                        |
| `config.server.auth.mode`        | Auth mode: `session`, `header`, or `none`                                   | `session`                                  |
| `secrets.adminUsername`          | Admin username (plain string = chart creates it in secret)                  | `"admin"`                                  |
| `secrets.adminPassword`          | Admin password (plain string = chart creates it in secret)                  | `"ChangeThisImmediately2026!"`             |
| `secrets.dbPassword`             | DB password – plain string = chart creates; object with `secretKeyRef` = use external secret | `"password"` or `{ secretKeyRef: { name: "...", key: "..." } }` |
| `secrets.sessionSecret`          | Session secret – plain string = chart creates; object with `secretKeyRef` = external | random base64 string or external ref       |
| `secrets.OIDCClientSecret`       | OIDC client secret – plain string = chart creates; object with `secretKeyRef` = external | random base64 string or external ref       |
| `secrets.SAMLCert`               | SAML certificate (optional, plain string = chart creates empty key)         | `""`                                       |
| `resources.requests.memory`      | Memory request                                                              | `256Mi`                                    |
| `resources.requests.cpu`         | CPU request                                                                 | `250m`                                     |
| `resources.limits.memory`        | Memory limit                                                                | `1Gi`                                      |
| `resources.limits.cpu`           | CPU limit                                                                   | `1000m`                                    |

### OIDC SSO without PostgreSQL

```yaml
database:
  enabled: false # Do not deploy bundled PostgreSQL
config:
  database:
    enabled: false # Disable application database access
  server:
    auth:
      mode: session
    cors:
      origin: https://crossview.example.com
  sso:
    oidc:
      enabled: true
      issuer: https://idp.example.com/realms/company
      clientId: crossview-client
      providerName: "Company SSO"
      providerIcon: "https://idp.example.com/sso-icon.svg"
secrets:
  sessionSecret:
    secretKeyRef:
      name: crossview-auth
      key: session-secret
  OIDCClientSecret:
    secretKeyRef:
      name: crossview-auth
      key: oidc-client-secret
```

Create the referenced Secret first using your secret-management workflow.
Keep the session secret stable across restarts and replicas.
SSO-only users have the `user` role; password inputs, the password Sign In
button, and the "Or continue with" divider are hidden. For both local password
login and SSO, keep `config.database.enabled: true` and configure PostgreSQL.
Set `database.enabled: false` alone when using an external PostgreSQL server.

OIDC branding is emitted as `OIDC_PROVIDER_NAME` and `OIDC_PROVIDER_ICON` in the
ConfigMap and consumed by the Deployment. With `config.ref`, add these keys to
your external ConfigMap to customize branding; missing keys are optional and
retain the UI defaults. See [SSO setup](../../docs/SSO_SETUP.md) for details.

### SAML login-button branding

Add these optional settings to your existing SAML configuration:

```yaml
config:
  sso:
    saml:
      providerName: "Company SSO"
      providerIcon: "https://idp.example.com/sso-icon.svg"
```

These values are emitted as `SAML_PROVIDER_NAME` and `SAML_PROVIDER_ICON`.
If using `config.ref`, add those keys to the external ConfigMap. The Deployment
references are optional, so older ConfigMaps remain compatible. An unset or
blank name displays "Sign in with SAML"; an unset or unavailable icon retains
the default SAML icon. SAML does not derive names or icons from its issuer.
Icon URLs must be browser-accessible. Branding does not enable SAML or implement
assertion validation; see the [SSO guide](../../docs/SSO_SETUP.md).

## Secret handling modes

The chart supports two ways to handle secrets:

1. **Chart-created secrets (development / quick setup)**  
   Provide plain strings → the chart automatically creates one Kubernetes Secret named `<release-name>-secrets` (e.g. `crossview-secrets`):

   ```yaml
   secrets:
     adminUsername: admin
     adminPassword: super-secret
     dbPassword: db-pass-123
     sessionSecret: random-session-key
     OIDCClientSecret: oidc-secret-here
     SAMLCert: ""
   ```

2. **External secrets (production / secure)**  
   Use `secretKeyRef` → the chart does not create secrets, it only references existing ones:

   ```yaml
   secrets:
     adminUsername: admin
     adminPassword: super-secret
     dbPassword:
       secretKeyRef:
         name: prod-db-secrets
         key: password
     sessionSecret:
       secretKeyRef:
         name: session-secrets
         key: key
     OIDCClientSecret:
       secretKeyRef:
         name: oidc-credentials
         key: client-secret
   ```

## Upgrading

```bash
helm upgrade crossview ./helm/crossview \
  -f /path/to/your-values.yaml \
  --namespace crossview
```

## Uninstalling

```bash
helm uninstall crossview --namespace crossview
```

## Using External Database

If you want to use an external database instead of the included PostgreSQL:

```bash
helm install crossview ./helm/crossview \
  --namespace crossview \
  --create-namespace \
  --set database.enabled=false \
  --set config.database.host=your-external-db-host \
  --set config.database.port=5432 \
  --set secrets.dbPassword.secretKeyRef.name=prod-db-secrets \
  --set secrets.dbPassword.secretKeyRef.key=password \
  --set secrets.sessionSecret=your-session-secret
```

### Bundled PostgreSQL security scans

Image scanners may flag the bundled `postgres:18-alpine` image (all
findings are in upstream's `gosu` binary, not in Crossview). No newer
upstream tag clears them yet; the floating tag picks up a fixed rebuild
automatically once published. For production, use an external database
as shown above.

## Context Alias Labels

To display short labels for long context names in the UI, set `config.server.contextAliases`:

```yaml
config:
  server:
    contextAliases:
      kind-kind: KIND
      dev-cluster: DEV
```

Equivalent CLI example:

```bash
helm upgrade --install crossview ./helm/crossview \
  --set-json 'config.server.contextAliases={"kind-kind":"KIND","dev-cluster":"DEV"}'
```

## Managed Resources Performance

For clusters with 10k+ managed resources, tune the cache and listing
behavior or page through `GET /api/managed` with `limit`, `continue`,
`kind`, and `search`:

```yaml
config:
  server:
    managed:
      cacheTTLSeconds: 300
      pageSize: 1000
      maxItemsPerType: 5000
      maxConcurrency: 10
```

## Ingress Configuration

To enable Ingress with TLS:

```bash
helm install crossview ./helm/crossview \
  --namespace crossview \
  --create-namespace \
  --set ingress.enabled=true \
  --set ingress.hosts[0].host=crossview.example.com \
  --set ingress.tls[0].secretName=crossview-tls \
  --set ingress.tls[0].hosts[0]=crossview.example.com
```

## Gateway API Configuration

As an alternative to Ingress, the chart can render an `HTTPRoute` (Gateway API)
that attaches to an existing `Gateway`. This requires the Gateway API CRDs and a
Gateway controller already installed in the cluster.

```bash
helm install crossview ./helm/crossview \
  --namespace crossview \
  --create-namespace \
  --set gatewayAPI.enabled=true \
  --set gatewayAPI.httpRoute.parentRefs[0].name=my-gateway \
  --set gatewayAPI.httpRoute.parentRefs[0].namespace=gateway-system \
  --set gatewayAPI.httpRoute.hostnames[0]=crossview.example.com
```

Key `gatewayAPI.httpRoute` values:

| Field | Description |
| --- | --- |
| `apiVersion` | HTTPRoute apiVersion (default `gateway.networking.k8s.io/v1`; set `gateway.networking.k8s.io/v1beta1` for older controllers) |
| `parentRefs` | List of Gateways to attach to. `name` is required; `namespace`, `sectionName`, `port`, `group`, `kind` are optional |
| `hostnames` | Hostnames the route matches. Omit/empty to match all hostnames on the Gateway |
| `rules` | Routing rules. Each rule may override `matches`, `filters`, `backendRefs` and `timeouts`. Default: a single `PathPrefix` `/` match routed to the crossview service |
| `annotations` / `labels` | Extra metadata on the HTTPRoute |

Enable only one of `ingress` or `gatewayAPI` at a time.

## Important Notes

- When `config.server.auth.mode` = `session`, provide `secrets.sessionSecret`; provide `secrets.dbPassword` when application database access is enabled. SSO-only sessions can disable both database settings.
- When `config.server.auth.mode` = `header` or `none` → database can be disabled (`database.enabled: false`), no DB/session secret needed
- Secrets are injected as environment variables (`DB_PASS`, `SESSION_SECRET`, `OIDC_CLIENT_SECRET`, etc.)
- For production, prefer `secretKeyRef` to avoid storing sensitive values in Helm values
- The secret name is `<release-name>-secrets` (e.g. `crossview-secrets` when using fixed release name `crossview`)
- All secrets use lowercased keys in the secret (e.g. `dbpassword`, `admin-username`). The chart handles renaming automatically

## Support

For issues and questions, please visit: https://github.com/crossplane-contrib/crossview